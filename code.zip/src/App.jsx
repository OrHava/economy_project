

import Footer from './Footer'
import ActuarialCalculator from './ActuarialCalculator'
import Sidebar from './Sidebar';
function App() {


  return(
    <>
       <Sidebar/>
       <ActuarialCalculator/>

      <Footer/>

    
    </>
 

  );



}

export default App
